int check_number(char *ip_part); 
int ip_valid(char *ip); 
void get_ip(char * hostname); 
void get_info_ip_address(char *ipAddress);
