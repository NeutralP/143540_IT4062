#ifndef HANDLE_STRING_H
#define HANDLE_STRING_H

/**
 * Break password down to alpha and numerical
*/
int breakPassword(char *password, char *alpha, char *num);

#endif